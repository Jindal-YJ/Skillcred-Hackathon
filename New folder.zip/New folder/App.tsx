
import React, { useState, useCallback } from 'react';
import type { GeneratedContent, InputType } from './types';
import Header from './components/Header';
import InputForm from './components/InputForm';
import LoadingSpinner from './components/LoadingSpinner';
import ResultsDisplay from './components/ResultsDisplay';
import { generateContent } from './services/geminiService';

const App: React.FC = () => {
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [generatedContent, setGeneratedContent] = useState<GeneratedContent | null>(null);

  const handleGenerate = useCallback(async (inputType: InputType, data: string | File) => {
    setIsLoading(true);
    setError(null);
    setGeneratedContent(null);

    try {
      const content = await generateContent(inputType, data);
      setGeneratedContent(content);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred.');
    } finally {
      setIsLoading(false);
    }
  }, []);
  
  const handleStartOver = useCallback(() => {
    setGeneratedContent(null);
    setError(null);
  }, []);

  return (
    <div className="min-h-screen bg-gray-50 font-sans text-gray-800">
      <Header />
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {isLoading ? (
            <LoadingSpinner />
          ) : error ? (
            <div className="text-center p-8 bg-white rounded-lg shadow-lg animate-fade-in">
              <h2 className="text-2xl font-bold text-red-600 mb-4">Generation Failed</h2>
              <p className="text-gray-600 mb-6">{error}</p>
              <button
                onClick={handleStartOver}
                className="bg-primary text-white font-bold py-2 px-6 rounded-lg hover:bg-blue-800 transition-colors"
              >
                Try Again
              </button>
            </div>
          ) : generatedContent ? (
            <ResultsDisplay content={generatedContent} onStartOver={handleStartOver} />
          ) : (
            <InputForm onGenerate={handleGenerate} />
          )}
        </div>
      </main>
      <footer className="text-center py-4 text-gray-500 text-sm">
        <p>Powered by Google Gemini</p>
      </footer>
    </div>
  );
};

export default App;
