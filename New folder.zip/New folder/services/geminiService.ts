import type { GeneratedContent } from '../types';
import { InputType } from '../types';

/**
 * Sends a request to the backend server to generate a study guide and quiz.
 * @param inputType - The type of input ('text', 'pdf', 'image').
 * @param data - The actual data, either a string for text or a File object.
 * @returns A promise that resolves to the generated content.
 */
export const generateContent = async (inputType: InputType, data: string | File): Promise<GeneratedContent> => {
  const formData = new FormData();
  formData.append('inputType', inputType);

  if (inputType === InputType.TEXT) {
    if (typeof data !== 'string') {
      throw new Error('Invalid data for text input. A string is expected.');
    }
    formData.append('topic', data);
  } else {
    if (!(data instanceof File)) {
      throw new Error('Invalid data for file input. A File object is expected.');
    }
    // The 'file' key must match the key expected by the backend API
    formData.append('file', data);
  }

  // Call the backend API at port 8000 explicitly
  const response = await fetch('http://localhost:8000/api/generate', {
    method: 'POST',
    body: formData,
  });

  if (!response.ok) {
    // Try to parse a JSON error response from the backend
    const errorData = await response.json().catch(() => ({ detail: 'An unknown server error occurred.' }));
    throw new Error(errorData.detail || 'Failed to generate content from the backend.');
  }

  const result = await response.json();

  // Basic validation to ensure the response shape from the backend is correct
  if (!result.studyGuide || !Array.isArray(result.quiz)) {
    throw new Error("Invalid response structure from the backend.");
  }

  return result as GeneratedContent;
};
