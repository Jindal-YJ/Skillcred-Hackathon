import os
import json
from dotenv import load_dotenv
from fastapi import FastAPI, UploadFile, File, Form, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import google.generativeai as genai
import uvicorn

# Load environment variables from .env file
load_dotenv()

app = FastAPI()

# Allow requests from your frontend development server
origins = [
    "http://localhost:3000", # Common port for Vite/Create React App
    "http://127.0.0.1:3000",
    "null" # Allow requests from file:// protocol (local HTML file)
] 

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configure the Gemini API from environment variables
try:
    api_key = os.getenv("API_KEY")
    if not api_key:
        raise ValueError("API_KEY environment variable not set.")
    genai.configure(api_key=api_key)
except Exception as e:
    # This will prevent the app from starting if the API key is not set
    print(f"Fatal Error: Could not configure Gemini API. {e}")
    exit()


@app.post("/api/generate")
async def generate(inputType: str = Form(...), topic: str = Form(None), file: UploadFile = File(None)):
    try:
        study_and_quiz_schema = {
            "type": "object",
            "properties": {
                "studyGuide": {
                    "type": "string",
                    "description": "A comprehensive study guide on the topic, formatted in Markdown. Should include headings, subheadings, bullet points, and bold text for key terms.",
                },
                "quiz": {
                    "type": "array",
                    "description": "An array of 5 multiple-choice questions to test understanding of the study guide.",
                    "items": {
                        "type": "object",
                        "properties": {
                            "question": {"type": "string", "description": "The question text."},
                            "options": {"type": "array", "items": {"type": "string"}, "description": "An array of 4 distinct possible answers."},
                            "correctAnswer": {"type": "string", "description": "The single correct answer from the provided options."},
                        },
                        "required": ["question", "options", "correctAnswer"],
                    },
                },
            },
            "required": ["studyGuide", "quiz"],
        }
        
        parts = []
        if inputType == 'text':
            if not topic:
                raise HTTPException(status_code=400, detail="Text topic is required for text input type.")
            prompt = f'Create a detailed study guide and a 5-question multiple-choice quiz for the topic: "{topic}". The study guide should be in Markdown format.'
            parts.append({"text": prompt})
        elif inputType == 'image':
            if not file:
                raise HTTPException(status_code=400, detail="File is required for image input type.")
            image_data = await file.read()
            # The genai library expects a PIL Image object or bytes, not a complex structure
            image_part = {"inline_data": {"mime_type": file.content_type, "data": image_data}}
            prompt = "Analyze the contents of this image and generate a detailed study guide in Markdown format and a 5-question multiple-choice quiz based on it."
            parts.append(image_part)
            parts.append({"text": prompt})
        else:
            raise HTTPException(status_code=400, detail=f"Unsupported input type: {inputType}")
        
        # Use the gemini-1.5-flash model for both text and image analysis
        model_name = "gemini-1.5-flash"
        
        model = genai.GenerativeModel(
            model_name=model_name,
            generation_config={"response_mime_type": "application/json", "response_schema": study_and_quiz_schema, "temperature": 0.7}
        )
        
        response = model.generate_content(parts)
        
        # FastAPI can directly return Pydantic models or dicts, which it will serialize to JSON.
        # No need to manually load and dump json.
        response_text = response.text.strip()
        cleaned_json_text = response_text.replace("```json", "").replace("```", "").strip()

        return json.loads(cleaned_json_text)

    except Exception as e:
        print(f"An error occurred: {e}")
        return JSONResponse(status_code=500, content={"detail": f"An internal server error occurred: {e}"})

if __name__ == "__main__":
    # The default port for uvicorn is 8000
    uvicorn.run(app, host="0.0.0.0", port=8000)