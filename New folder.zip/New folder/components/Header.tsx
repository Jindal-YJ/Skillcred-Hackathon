
import React from 'react';
import { SparklesIcon } from './icons/SparklesIcon';

const Header: React.FC = () => {
  return (
    <header className="bg-white shadow-md">
      <div className="container mx-auto px-4 py-4 flex items-center justify-center">
        <SparklesIcon className="w-8 h-8 text-primary mr-3" />
        <h1 className="text-3xl font-bold text-gray-800">
          Study Buddy <span className="text-primary">AI</span>
        </h1>
      </div>
    </header>
  );
};

export default Header;
