
import React, { useState, useMemo } from 'react';
import type { QuizQuestion } from '../types';

interface QuizProps {
  questions: QuizQuestion[];
}

const Quiz: React.FC<QuizProps> = ({ questions }) => {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [userAnswers, setUserAnswers] = useState<(string | null)[]>(Array(questions.length).fill(null));
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [showResults, setShowResults] = useState(false);

  const currentQuestion = questions[currentQuestionIndex];
  const score = useMemo(() => {
    return userAnswers.reduce((acc, answer, index) => {
      return answer === questions[index].correctAnswer ? acc + 1 : acc;
    }, 0);
  }, [userAnswers, questions]);

  const handleOptionSelect = (option: string) => {
    if (isAnswered) return;
    setSelectedOption(option);
  };
  
  const handleCheckAnswer = () => {
    if (!selectedOption) return;
    setIsAnswered(true);
    const newAnswers = [...userAnswers];
    newAnswers[currentQuestionIndex] = selectedOption;
    setUserAnswers(newAnswers);
  };
  
  const handleNext = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
      setSelectedOption(null);
      setIsAnswered(false);
    } else {
      setShowResults(true);
    }
  };

  const handleTryAgain = () => {
    setCurrentQuestionIndex(0);
    setUserAnswers(Array(questions.length).fill(null));
    setSelectedOption(null);
    setIsAnswered(false);
    setShowResults(false);
  }

  if (showResults) {
    return (
      <div className="text-center animate-fade-in">
        <h3 className="text-2xl font-bold mb-4">Quiz Complete!</h3>
        <p className="text-lg mb-6">Your Score: <span className="font-bold text-primary">{score} / {questions.length}</span></p>
        <button
          onClick={handleTryAgain}
          className="bg-primary text-white font-bold py-2 px-6 rounded-lg hover:bg-blue-800 transition-colors"
        >
          Try Again
        </button>
      </div>
    );
  }

  return (
    <div className="animate-fade-in">
      <div className="mb-4 text-sm text-gray-600">
        Question {currentQuestionIndex + 1} of {questions.length}
      </div>
      <h3 className="text-lg font-semibold mb-6">{currentQuestion.question}</h3>
      <div className="space-y-3 mb-6">
        {currentQuestion.options.map((option, index) => {
          let buttonClass = "w-full text-left p-3 border rounded-lg transition-colors ";
          if (isAnswered) {
            if (option === currentQuestion.correctAnswer) {
              buttonClass += "bg-green-100 border-green-500 text-green-800";
            } else if (option === selectedOption) {
              buttonClass += "bg-red-100 border-red-500 text-red-800";
            } else {
               buttonClass += "bg-gray-100 border-gray-300 text-gray-500";
            }
          } else {
            if (option === selectedOption) {
              buttonClass += "bg-blue-100 border-primary";
            } else {
              buttonClass += "border-gray-300 hover:bg-gray-100";
            }
          }
          return (
            <button key={index} onClick={() => handleOptionSelect(option)} className={buttonClass} disabled={isAnswered}>
              {option}
            </button>
          );
        })}
      </div>
      {!isAnswered ? (
        <button onClick={handleCheckAnswer} disabled={!selectedOption} className="w-full bg-primary text-white font-bold py-3 px-4 rounded-lg hover:bg-blue-600 disabled:bg-gray-400">Check Answer</button>
      ) : (
        <button onClick={handleNext} className="w-full bg-primary text-white font-bold py-3 px-4 rounded-lg hover:bg-blue-800">{currentQuestionIndex < questions.length - 1 ? 'Next Question' : 'View Results'}</button>
      )}
    </div>
  );
};

export default Quiz;
