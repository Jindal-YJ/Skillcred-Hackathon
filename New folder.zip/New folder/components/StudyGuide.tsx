
import React, { useCallback } from 'react';

interface StudyGuideProps {
  guideContent: string;
}

const StudyGuide: React.FC<StudyGuideProps> = ({ guideContent }) => {
  
  const handleDownload = useCallback(() => {
    if (!(window as any).jspdf) {
      console.error("jsPDF not loaded");
      alert("PDF generation library not loaded. Please try again later.");
      return;
    }
    const { jsPDF } = (window as any).jspdf;
    if (!jsPDF) {
      console.error("jsPDF not available");
      alert("PDF generation failed. Please try again later.");
      return;
    }
    const doc = new jsPDF();

    // Simple markdown to text conversion for PDF
    const plainText = guideContent
      .replace(/#+\s/g, '')      // Remove headings
      .replace(/\*\*/g, '')      // Remove bold
      .replace(/\*/g, '  - ')     // Convert list items
      .replace(/(\r\n|\n|\r)/gm, "\n");

    const splitText = doc.splitTextToSize(plainText, 180);
    doc.text(splitText, 10, 10);
    doc.save('study-guide.pdf');
  }, [guideContent]);

  return (
    <div className="animate-fade-in">
      <div className="prose max-w-none p-4 bg-gray-50 rounded-lg border border-gray-200 h-96 overflow-y-auto mb-6">
        {guideContent.split('\n').map((line, index) => {
            if (line.startsWith('# ')) {
                return <h1 key={index} className="text-2xl font-bold mb-4 text-gray-800">{line.substring(2)}</h1>
            }
            if (line.startsWith('## ')) {
                return <h2 key={index} className="text-xl font-bold mt-4 mb-2 text-gray-700">{line.substring(3)}</h2>
            }
            if (line.startsWith('* ') || line.startsWith('- ')) {
                return <li key={index} className="ml-5 list-disc">{line.substring(2)}</li>
            }
            return <p key={index} className="my-2">{line}</p>
        })}
      </div>
      <button
        onClick={handleDownload}
        className="w-full bg-primary text-white font-bold py-3 px-4 rounded-lg hover:bg-blue-800 transition-colors"
      >
        Download as PDF
      </button>
    </div>
  );
};

export default StudyGuide;
