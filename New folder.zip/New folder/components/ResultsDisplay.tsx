
import React, { useState } from 'react';
import type { GeneratedContent } from '../types';
import StudyGuide from './StudyGuide';
import Quiz from './Quiz';

interface ResultsDisplayProps {
  content: GeneratedContent;
  onStartOver: () => void;
}

const ResultsDisplay: React.FC<ResultsDisplayProps> = ({ content, onStartOver }) => {
  const [activeTab, setActiveTab] = useState<'guide' | 'quiz'>('guide');

  return (
    <div className="animate-fade-in">
      <div className="flex justify-center mb-6">
        <button
          onClick={onStartOver}
          className="bg-gray-200 text-gray-700 font-bold py-2 px-6 rounded-lg hover:bg-gray-300 transition-colors"
        >
          ← Start Over
        </button>
      </div>

      <div className="bg-white p-6 sm:p-8 rounded-xl shadow-lg">
        <div className="flex border-b border-gray-200 mb-6">
          <button
            onClick={() => setActiveTab('guide')}
            className={`flex-1 py-3 font-medium transition-colors ${
              activeTab === 'guide' ? 'border-b-2 border-primary text-primary' : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            Study Guide
          </button>
          <button
            onClick={() => setActiveTab('quiz')}
            className={`flex-1 py-3 font-medium transition-colors ${
              activeTab === 'quiz' ? 'border-b-2 border-primary text-primary' : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            Quiz
          </button>
        </div>

        <div>
          {activeTab === 'guide' ? (
            <StudyGuide guideContent={content.studyGuide} />
          ) : (
            <Quiz questions={content.quiz} />
          )}
        </div>
      </div>
    </div>
  );
};

export default ResultsDisplay;
