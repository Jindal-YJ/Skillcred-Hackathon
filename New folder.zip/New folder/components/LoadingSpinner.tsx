
import React, { useState, useEffect } from 'react';

const messages = [
  "Analyzing your topic...",
  "Consulting with digital scholars...",
  "Crafting your study guide...",
  "Designing challenging quiz questions...",
  "Finalizing your personalized plan...",
];

const LoadingSpinner: React.FC = () => {
    const [messageIndex, setMessageIndex] = useState(0);

    useEffect(() => {
        const interval = setInterval(() => {
            setMessageIndex(prevIndex => (prevIndex + 1) % messages.length);
        }, 2000);
        return () => clearInterval(interval);
    }, []);

    return (
        <div className="flex flex-col items-center justify-center text-center p-8 bg-white rounded-lg shadow-lg animate-fade-in">
            <div className="w-16 h-16 border-4 border-t-4 border-gray-200 border-t-primary rounded-full animate-spin mb-6"></div>
            <h2 className="text-xl font-semibold text-gray-700">Generating Your Study Plan</h2>
            <p className="text-gray-500 mt-2 transition-opacity duration-500">{messages[messageIndex]}</p>
        </div>
    );
};

export default LoadingSpinner;
