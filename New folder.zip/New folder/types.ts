
export enum InputType {
  TEXT = 'text',
  PDF = 'pdf',
  IMAGE = 'image',
}

export interface QuizQuestion {
  question: string;
  options: string[];
  correctAnswer: string;
}

export interface GeneratedContent {
  studyGuide: string;
  quiz: QuizQuestion[];
}

// For jspdf from CDN
declare global {
  interface Window {
    jspdf: {
      jsPDF: new (options?: any) => any;
    };
  }
}
